# Challenge 3

> DISCLAIMER: it is strongly recommended to run any untrusted code in a virtual machine to avoid potential risks

make sure you have `make`, `gcc` and `linux-headers` installed on your machine.

```bash
$ sudo apt install linux-headers-$(uname -r)
$ sudo apt install build-essential
```

now run the following command inorder to build the module:

```bash
$ make
```

it will generate a `birlug.ko` file which you can attach/detach to your kernel:
```bash
$ sudo insmod birlug.ko
$ sudo rmmod birlug
```

check kernel messages and retrive the answer:
```bash
$ sudo dmesg
```
